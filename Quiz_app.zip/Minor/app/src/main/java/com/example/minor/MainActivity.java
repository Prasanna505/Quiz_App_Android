package com.example.minor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText e;
    Button b,b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e = (EditText) findViewById(R.id.name);
        b = (Button)findViewById(R.id.startbut);
        b1 = (Button) findViewById(R.id.about);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n;
                n = e.getText().toString();
                if(n.equals("")) {
                    Toast.makeText(getApplicationContext(), "First Enter Your Name to Start a Quiz", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent i = new Intent(getApplicationContext(),question.class);
                    i.putExtra("message key",n);
                    e.setText("");
                    startActivity(i);
                }
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent i = new Intent(getApplicationContext(),about.class);
                    startActivity(i);
            }
        });
    }
}