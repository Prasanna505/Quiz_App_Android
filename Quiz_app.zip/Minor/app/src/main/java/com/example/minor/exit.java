package com.example.minor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class exit extends AppCompatActivity {

    Button b;
    TextView cr,wr,to;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quit);
        b= (Button) findViewById(R.id.restart);
        cr = (TextView) findViewById(R.id.correctv) ;
        wr = (TextView) findViewById(R.id.wrongv) ;
        to = (TextView) findViewById(R.id.finalv) ;

        Intent j = getIntent();
        String s = j.getStringExtra("k");
        String s1 = j.getStringExtra("k1");
        int tp = Integer.parseInt(s);
        int total = tp;
        String st = Integer.toString(total);
        wr.setText(s1);
        cr.setText(s);
        to.setText(st);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });
    }
}
