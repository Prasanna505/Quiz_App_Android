package com.example.minor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class question extends AppCompatActivity {

//   Button b1,b2,b3,b4,b5;
   TextView h,qq;
   String count= String.valueOf(0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

//        b1=(Button) findViewById(R.id.one);
//        b2=(Button) findViewById(R.id.two);
//        b3=(Button) findViewById(R.id.three);
//        b4=(Button) findViewById(R.id.four);
//        b5=(Button) findViewById(R.id.five);
        h=(TextView) findViewById(R.id.head1);
//        qq=(TextView) findViewById(R.id.qu);



        Intent j = getIntent();
        String n = j.getStringExtra("message key");
        h.setText("Hello "+n);


        loadFragment(new frag1());

//        b2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                loadFragment(new frag2());
//            }
//        });
//
//        b3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                loadFragment(new frag3());
//            }
//        });
//
//        b4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                loadFragment(new frag4());
//            }
//        });
//
//        b5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                loadFragment(new frag5());
//            }
//        });

    }

    private void loadFragment(Fragment f)
    {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.f1,f);
        ft.commit();
    }


    public String getdata()
    {
        return count;
    }
}