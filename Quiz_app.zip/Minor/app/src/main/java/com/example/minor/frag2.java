package com.example.minor;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class frag2 extends Fragment {

    Button b,w;
    RadioGroup r1;
    RadioButton r;
    TextView t,h;
    int tp,tn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.second,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        b = (Button) view.findViewById(R.id.next2);
        w = (Button) view.findViewById(R.id.quit2);
        r1= (RadioGroup) view.findViewById(R.id.rg2);
        t = (TextView) view.findViewById(R.id.scorev2);

        Bundle bd = getArguments();
        String s = String.valueOf(bd.getString("key"));
        String s1 = String.valueOf(bd.getString("key1"));
        t.setText(s);
        tp = Integer.parseInt(s);
        tn = Integer.parseInt(s1);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, int c) {
                        switch (c)
                        {
                            case R.id.Q2b:
                                Toast.makeText(getContext(),"Correct",Toast.LENGTH_SHORT).show();
                                tp = tp+1;
                                break;
                            case R.id.Q2a: case R.id.Q2c:
                            case R.id.Q2d:

                                Toast.makeText(getContext(),"Wrong",Toast.LENGTH_SHORT).show();
                                tn = tn+1;
                                break;

                        }
                    }
                });
                r1.clearCheck();
                loadFragment(new frag3());
            }
        });

        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(getContext(),exit.class);
                String s = Integer.toString(tp);
                String s1 = Integer.toString(tn);
                j.putExtra("k",s);
                j.putExtra("k1",s1);
                startActivity(j);
            }
        });
    }
    private void loadFragment(Fragment f)
    {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        String s = Integer.toString(tp);
        String s1 = Integer.toString(tn);
        Bundle bd = new Bundle();
        bd.putString("key",s);
        bd.putString("key1",s1);
        f.setArguments(bd);
        ft.replace(R.id.f1,f);
        ft.commit();
    }
}
